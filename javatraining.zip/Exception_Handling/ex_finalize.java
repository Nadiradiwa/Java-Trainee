package Exception_Handling;

public class ex_finalize {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ex_finalize o = new ex_finalize();
		
		System.out.println("Hash code: "+o.hashCode());
		o = null;
		System.gc();
		System.out.println("End of the garbage collection");

	}
	protected void finalize() { //called finalize method by using System.gc()
		System.out.println("called finalize() method");
	}

}
