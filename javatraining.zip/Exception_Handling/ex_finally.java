package Exception_Handling;

public class ex_finally {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			int a=5, b=0;
			b=a/b;
		}finally {
			System.out.println("Im finally block.");
		}

	}

}
