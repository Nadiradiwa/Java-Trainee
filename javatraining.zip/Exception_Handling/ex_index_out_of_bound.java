package Exception_Handling;

public class ex_index_out_of_bound {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			int myarray[] = {1,2,3,4,5};
			System.out.println("Elements in the array"+myarray[6]);
		}catch(Exception e) {
			System.out.println(e);
		}
		System.out.println("Rest of the code");
		

	}

}
