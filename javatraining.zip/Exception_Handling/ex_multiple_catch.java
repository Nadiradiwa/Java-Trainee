package Exception_Handling;

public class ex_multiple_catch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			int a[] = new int[6];
			a[7] = 43;
			
		}catch (ArithmeticException e) {
			System.out.println("Arithmetic Exception"+e);
		}catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("Index out of bounds"+e);
		}

	}

}
