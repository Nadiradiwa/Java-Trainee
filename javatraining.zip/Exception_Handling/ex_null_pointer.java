package Exception_Handling;

public class ex_null_pointer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
		String name=null;
		int str_len = name.length();
		System.out.println("Length of the string"+str_len);
		
		}catch(NullPointerException e) {
			System.out.println(e);
		}
		System.out.println("Rest of the code");

	}

}
