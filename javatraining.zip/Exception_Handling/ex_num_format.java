package Exception_Handling;

public class ex_num_format {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		
		int decimalExample = Integer.parseInt("20");
		int signedPositiveEx = Integer.parseInt("+20");
		int signedNegativeEx = Integer.parseInt("-20");
		
		System.out.println("Value = "+decimalExample);
		System.out.println("Value = "+signedPositiveEx);
		System.out.println("Value = "+signedNegativeEx);
		
		try {

		int a = Integer.parseInt("null");
		
		}catch(NullPointerException e) {
			System.out.println(e);
		}
		
		System.out.println("Rest of the code");
		int signedNegativeEx1 = Integer.parseInt("-120");
		System.out.println("exception");

	}

}
