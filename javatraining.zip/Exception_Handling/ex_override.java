package Exception_Handling;

import java.io.*;

class Parent{
	
	void msg() throws IOException {
		System.out.println("parent method");
	}
}
public class ex_override extends Parent{
	
	void msg() throws IOException {
		System.out.println("child method");
	}

	public static void main(String[] args) throws IOException{
		// TODO Auto-generated method stub
		
		Parent p = new ex_override();
		p.msg();

	}

}
