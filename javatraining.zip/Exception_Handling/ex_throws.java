package Exception_Handling;

import java.io.*;

public class ex_throws {
	
	void M() throws IOException{
		System.out.println("Device operation performed");
	}
	
	void M1() throws ClassNotFoundException{
		System.out.println("Class not found exception");
	}

	public static void main(String[] args) throws IOException,ClassNotFoundException{
		// TODO Auto-generated method stub
		
		 ex_throws o = new ex_throws();
		 o.M();
		 o.M1();
		 
		 System.out.println("Normal flow");

	}

}
