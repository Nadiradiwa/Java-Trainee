 package Looping_Statements;

 import java.util.*;
public class arr_ex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int no_of_emp;
		
		Scanner s = new Scanner(System.in);
		
		System.out.println("Enter number of employee: ");
		no_of_emp = s.nextInt();
		
		int emp_id[] = new int[no_of_emp];
		String emp_name[] = new String[no_of_emp];
		String dept[] = new String[no_of_emp];
		
		System.out.println("Enter the employee details ");
		
		for(int i=0;i<no_of_emp;i++) {
			System.out.println("Employee id: ");
			emp_id[i] = s.nextInt();
			
			System.out.println("Employee Name   : ");
			emp_id[i] = s.nextInt();
			
			System.out.println("Employee id: ");
			emp_id[i] = s.nextInt();
		}

	}

}
