package Looping_Statements;
import java.util.Scanner;
public class while_ex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		 int i,nos;
		 i=0;
		 
		 Scanner s = new Scanner(System.in);
		 
		 System.out.println("Enter the no of employess");
		 nos = s.nextInt();
		 
		 while(i<=nos) {
			 String emp_name,doj;
			 int emp_id;
			 float bas_sal,hra,da,tax,pr,tot_ear,tot_ded,gross;
			 
			 System.out.println("Enter employee name: ");
			 emp_name = s.next();
			 
			 System.out.println("Enter employee id: ");
			 emp_id = s.nextInt();
			 
			 System.out.println("Enter employee basic salary: ");
			 bas_sal = s.nextFloat();
			 
				if(bas_sal>1000 & bas_sal<2000) {
					hra=12*10/100;
					da=bas_sal*10/100;
					tax=bas_sal*12/100;
					pr=bas_sal*8/100;
					
				}else if(bas_sal>2000 & bas_sal<3000) {
					hra=15*10/100;
					da=bas_sal*15/100;
					tax=bas_sal*14/100;
					pr=bas_sal*10/100;
					
				}else if(bas_sal>3000) {
					hra=17*10/100;
					da=bas_sal*16/100;
					tax=bas_sal*16/100;
					pr=bas_sal*12/100;
					
				}else {
					hra=9*10/100;
					da=bas_sal*5/100;
					tax=bas_sal*5/100;
					pr=bas_sal*7/100;
					
				}
				tot_ear=bas_sal+hra+da;
				tot_ded=tax+pr;
				gross=tot_ear-tot_ded;
				
				System.out.println("======================================");
				System.out.println("Pay Slip for JAN-2022");
				System.out.println("======================================");
				System.out.println("Employee Name: "+emp_name+ "\t"+     "Employee_Id: "+emp_id);
				System.out.println("Basic Salary: "+bas_sal+ "\t"+     "pr Deduction:"+pr);
				System.out.println("HRA:"+hra +      "\t"              +"Tax:"+tax);
				System.out.println("DA: "+da);
				System.out.println("======================================");
				System.out.println("Total Earnings: "+tot_ear  + "\t"+     "Total Deduction:"+tot_ded);
				System.out.println("Gross Salary:"+gross);
				System.out.println("=======================================");
			 
			 

		 }

	}

}
