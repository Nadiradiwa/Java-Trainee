package Multi_Thread;

public class Sleep_ex extends Thread {
	
	public void run() {
		for (int i=0;i<10;i++) {
			try {
				Thread.sleep(100);
			}catch(InterruptedException e) {
				System.out.println(e);
			}
			System.out.println(i);
			System.out.println(Thread.currentThread().getName());
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Sleep_ex t1 = new Sleep_ex();
		Sleep_ex t2 = new Sleep_ex();
		Sleep_ex t3 = new Sleep_ex();
		
		t1.setPriority(8);
		t2.setPriority(7);
		t3.setPriority(6);
		
		t1.start();
		try {
			t2.join();
		}catch(Exception e) {
			System.out.println(e);
		}
		
		t2.start();
		try {
			t2.join();
		}catch(Exception e) {
			System.out.println(e);
		}
		t3.start();
		
		t1.setName("1st Thread");
		t2.setName("2nd Thread");
		t3.setName("3rd Thread");
		System.out.println(t1.getName());
		System.out.println(t2.getName());
		System.out.println(t3.getName());
		
		System.out.println("1st Thread priority"+t1.getPriority());
		System.out.println("2nd Thread priority"+t2.getPriority());
		System.out.println("3rd Thread priority"+t3.getPriority());

	}

}
