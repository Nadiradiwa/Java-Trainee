package Multi_Thread;

public class exercise_thread {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
