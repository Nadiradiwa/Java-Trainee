package Multi_Thread;
import java.util.*;

class Task1 extends Thread{
	
	public void run() {
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the n value");
		int n=in.nextInt();
		for(int i=0;i<n;i++) {
			System.out.println("Thread 1: "+i*i*i);
	}
  }
}

class Task2 extends Thread{
	
	public void run() {
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the n value");
		int n=in.nextInt();
		
		for(int i=0;i<n;i++) {
			
			if(i%2==0) {
				System.out.println("Thread 2: "+i);
			}
			
	}
}
	
}
public class multi_thread {

	public static void main(String[] args) {
		Task1 t1 = new Task1();
		Task2 t2 = new Task2();
		
		t1.start();
		t2.start();
	
	}
}

