package Multi_Thread;

public class sys_memory1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		long total = Runtime.getRuntime().freeMemory();
		int[] array = new int[10000000];
		array[0] = 1;
		if (array[0] == 3) {
			return;
		}
		
		long total2 = Runtime.getRuntime().freeMemory();
		
		System.gc();
		
		long total3 =  Runtime.getRuntime().freeMemory();
		
		System.out.println("Before: "+total);
		System.out.println("During: "+total2);
		System.out.println("After: "+total3);
		System.out.println("Change after : "+(total2-total3));


	}

}
