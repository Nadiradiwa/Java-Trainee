package javatrain;
import java.util.Scanner;
public class course {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int code;
		Scanner in = new Scanner(System.in);
		
		System.out.print("Please Enter Course Code: ");
		code = in.nextInt();
		
		switch(code){
		case 101:
			System.out.println("Department is CSE.");
			break;
		case 102:
			System.out.println("Department is EEE.");
			break;
		case 103:
			System.out.println("Department is MECH.");
			break;
		case 104:
			System.out.println("Department is CIVIL.");
			break;
	    default:
	    	System.out.println("Invalid Course Code");
		
		}

	}

}
