package javatrain;

public class demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hi Friends...<3");
		
		int course_id;
		String course_name;
		
		course_id=1001;
		course_name="Java programming";
		
		System.out.println("Course Id: "+course_id);
		System.out.println("Course Name: "+course_name);
	

	}

}
