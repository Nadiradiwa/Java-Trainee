package javatrain;

public class ex_if_else {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int acc_bal, with_amt;
		acc_bal =1000;
		with_amt=2200;
		
		if(acc_bal>with_amt) {
			System.out.println("Transaction Successfull..");
			System.out.println("Available balance: "+acc_bal);
		}else {
			System.out.println("Insufficient amount!!");
		}

	}

}
