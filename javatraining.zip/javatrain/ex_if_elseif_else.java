package javatrain;

public class ex_if_elseif_else {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int bas_sal,hra;
		
		bas_sal=500;
		
		if(bas_sal>1000 && bas_sal<2000) {
			hra=bas_sal*20/100;
			System.out.println("Basic Salary: "+bas_sal+"    HRA: "+hra);
			
		}else if(bas_sal>2000 && bas_sal<3000) {
			hra=bas_sal*25/100;
			System.out.println("Basic Salary: "+bas_sal+"    HRA: "+hra);
			
		}else if(bas_sal>3000){
			hra=bas_sal*28/100;
			System.out.println("Basic Salary: "+bas_sal+"    HRA: "+hra);
			
		}else {
			hra=bas_sal*10/100;
			System.out.println("Basic Salary: "+bas_sal+"    HRA: "+hra);
			
		}


	}

}
