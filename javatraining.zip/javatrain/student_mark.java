package javatrain;
import java.util.Scanner;
public class student_mark {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String stud_name,dob,dept,grade,result;
		int m1,m2,m3,tm,am, regno;
		
		Scanner in = new Scanner(System.in);
		System.out.println("Please Enter Student Name: ");
		stud_name = in.next();
		
		System.out.println("Please enter registration number: ");
		regno = in.nextInt();
		
		System.out.println("Please enter student date of birth: ");
		dob = in.next();
		
		System.out.println("Please enter Department: ");
		dept = in.next();
		
		System.out.println("Please enter mark 1 : ");
		m1 = in.nextInt();
		
		System.out.println("Please enter mark 2 : ");
		m2 = in.nextInt();
		
		System.out.println("Please enter mark 3 : ");
		m3 = in.nextInt();
		
		tm=m1+m2+m3;
		am=tm/3;
		
		if(am >= 80) {
			grade="A";
			result="Pass";
			
		}else if(am < 80 & am >= 60 ) {
			grade="B";
			result="Pass";
			
		}else if(am < 60 & am >=50 ) {
			grade="C";
			result="Pass";
			
		}else if(am < 50 & am >= 40 ) {
			grade="D";
			result="Pass";
			
		}else {
			grade="E";
			result="Fail";
			
		}
		
		System.out.println("                   Student Marklist                    ");
		System.out.println("_______________________________________________________");
		System.out.println("Student Name: "+stud_name+            "\t"+"D.O.B: "+dob);
		System.out.println("Reg No:"+regno);
		System.out.println("-------------------------------------------------------");
		System.out.println("Mark 1: "+m1+   "\t"+                "Department: "+dept);               
		System.out.println("Mark 2: "+m2);
		System.out.println("Mark 3: "+m3);
		System.out.println("");
		System.out.println("-------------------------------------------------------");
		System.out.println("Total Mark: "+tm+               "\t"+"Average Mark: "+am);
		System.out.println("Result: "+result+                   "\t"+"Grade: "+grade);
		System.out.println("-------------------------------------------------------");
		

	}
/*mark tu subject.. check tiga2 mark klu lebih dri pass mark bru pass, eg pass mrk:50 */
}
